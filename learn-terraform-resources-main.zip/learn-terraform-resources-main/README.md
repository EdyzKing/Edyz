# Learn Terraform Resources

This repo is a companion repo to the [Define Infrastructure with Terraform Resources](https://developer.hashicorp.com/terraform/tutorials/configuration-language/resource) tutorial, containing Terraform configuration files to provision two publicly-visible EC2 instances and an ELB.
